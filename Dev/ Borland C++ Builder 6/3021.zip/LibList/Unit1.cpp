//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormActivate(TObject *Sender) {
 TStringList	*lst = (TStringList*)Memo1->Lines;
 lst->Clear();
 char buf [255];
 TLibModule *lbm;
 AnsiString fname, sname, path, drv, dir, name, ext;
 for (lbm = LibModuleList; lbm; lbm = lbm->next) {
  GetModuleFileName((HMODULE)lbm->instance, buf, 254);
  fname = AnsiString(buf).Trim().UpperCase();
  if (!fname.IsEmpty())  lst->Add(AnsiString(int(lbm->instance)) + ": " + fname);
 }
}
//---------------------------------------------------------------------------
 